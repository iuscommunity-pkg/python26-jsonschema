{
  "type":"object",
  "class": "com.json.jsonschema.MyClass",
  "properties": {
    "name": {"type":"string"},
    "userfunc": {"type":"function"}
  }
}