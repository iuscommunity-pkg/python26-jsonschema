{
  "name": "Hello World Example Function",
  "userfunc": "function() { alert(\"Hello World!\"); }"
}
